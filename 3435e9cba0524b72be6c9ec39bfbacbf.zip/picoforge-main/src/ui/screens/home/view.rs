use crate::ui::components::{card::Card, page_view::PageView, tag::Tag};
use crate::ui::models::device::{DeviceMethod, FidoDeviceInfo, FirmwareType, FullDeviceStatus};
use crate::ui::screens::home::view_model::HomeViewModel;
use gpui::prelude::FluentBuilder;
use gpui::*;
use gpui_component::{ActiveTheme, StyledExt};
use gpui_component::{Icon, IconName, Theme, h_flex, progress::Progress, v_flex};

impl HomeViewModel {
    fn render_kv(
        label: &str,
        value: impl IntoElement,
        theme: &Theme,
        font_mono: bool,
    ) -> impl IntoElement {
        v_flex()
            .gap_1()
            .child(
                div()
                    .text_sm()
                    .text_color(theme.muted_foreground)
                    .child(label.to_string()),
            )
            .child(
                div()
                    .text_sm()
                    .font_weight(if font_mono {
                        FontWeight::NORMAL
                    } else {
                        FontWeight::MEDIUM
                    })
                    .font_family(if font_mono { "Mono" } else { "Sans" })
                    .text_color(theme.foreground)
                    .child(value),
            )
    }

    fn render_device_info(status: &FullDeviceStatus, theme: &Theme) -> impl IntoElement {
        let info = &status.info;
        let config = &status.config;

        Card::new()
            .title("设备信息")
            .icon(Icon::default().path("icons/cpu.svg"))
            .child(
                v_flex()
                    .gap_6()
                    .child(
                        div()
                            .grid()
                            .grid_cols(2)
                            .gap_4()
                            .child(Self::render_kv(
                                "序列号",
                                info.serial.clone(),
                                theme,
                                true,
                            ))
                            .child(Self::render_kv(
                                "固件版本",
                                format!("v{}", info.firmware_version),
                                theme,
                                true,
                            ))
                            .child(Self::render_kv(
                                "固件类型",
                                status.firmware_type.to_string(),
                                theme,
                                false,
                            ))
                            .child(Self::render_kv(
                                "VID:PID",
                                format!("{}:{}", config.vid, config.pid),
                                theme,
                                true,
                            ))
                            .child(Self::render_kv(
                                "产品名称",
                                config.product_name.clone(),
                                theme,
                                false,
                            )),
                    )
                    .child(div().h_px().bg(theme.border))
                    .child(
                        v_flex()
                            .gap_2()
                            .child(
                                h_flex()
                                    .justify_between()
                                    .text_sm()
                                    .child(
                                        div()
                                            .text_color(theme.muted_foreground)
                                            .child("闪存"),
                                    )
                                    .child(div().text_color(theme.foreground).child(
                                        if let (Some(used), Some(total)) =
                                            (info.flash_used, info.flash_total)
                                        {
                                            format!("{:.0} / {:.0} KB", used, total)
                                        } else {
                                            "暂无数据".to_string()
                                        },
                                    )),
                            )
                            .when(
                                info.flash_used.is_some() && info.flash_total.is_some(),
                                |this| {
                                    let used = info.flash_used.unwrap();
                                    let total = info.flash_total.unwrap();
                                    let flash_percent = (used as f32 / total as f32) * 100.0;
                                    this.child(Progress::new().value(flash_percent))
                                },
                            ),
                    ),
            )
    }

    fn render_fido_info(fido: Option<&FidoDeviceInfo>, theme: &Theme) -> impl IntoElement {
        Card::new()
            .title("FIDO2 信息")
            .icon(Icon::default().path("icons/shield.svg"))
            .child(if let Some(fido) = fido {
                v_flex()
                    .gap_3()
                    .text_sm()
                    .child(
                        h_flex()
                            .justify_between()
                            .items_center()
                            .flex_wrap()
                            .gap_1()
                            .child(div().text_color(theme.muted_foreground).child("AAGUID"))
                            .child(
                                div()
                                    .font_family("Mono")
                                    .text_color(theme.foreground)
                                    .child(fido.aaguid.clone()),
                            ),
                    )
                    .child(
                        h_flex()
                            .justify_between()
                            .items_center()
                            .flex_wrap()
                            .gap_1()
                            .child(
                                div()
                                    .text_color(theme.muted_foreground)
                                    .child("FIDO 版本"),
                            )
                            .child(div().text_color(theme.foreground).child(
                                if fido.versions.is_empty() {
                                    "N/A".to_string()
                                } else {
                                    fido.versions.join(" · ")
                                },
                            )),
                    )
                    .child(div().h_px().bg(theme.border))
                    .child(
                        h_flex()
                            .justify_between()
                            .items_center()
                            .child(div().text_color(theme.muted_foreground).child("设置PIN码"))
                            .child({
                                let pin_set =
                                    fido.options.get("clientPin").copied().unwrap_or(false);
                                Tag::new(if pin_set { "已设置" } else { "未设置" }).active(pin_set)
                            }),
                    )
                    .child(
                        h_flex()
                            .justify_between()
                            .items_center()
                            .child(
                                div()
                                    .text_color(theme.muted_foreground)
                                    .child("常驻密钥"),
                            )
                            .child({
                                let resident_keys_supported =
                                    fido.options.get("rk").copied().unwrap_or(false);
                                Tag::new(if resident_keys_supported {
                                    "支持"
                                } else {
                                    "不支持"
                                })
                                .active(resident_keys_supported)
                            }),
                    )
                    .child(
                        h_flex()
                            .justify_between()
                            .items_center()
                            .child(
                                div()
                                    .text_color(theme.muted_foreground)
                                    .child("最小 PIN 长度"),
                            )
                            .child(
                                div()
                                    .font_medium()
                                    .text_color(theme.foreground)
                                    .child(fido.min_pin_length.to_string()),
                            ),
                    )
                    .child(
                        h_flex()
                            .justify_between()
                            .items_center()
                            .child(
                                div()
                                    .text_color(theme.muted_foreground)
                                    .child("企业认证"),
                            )
                            .child(div().font_medium().text_color(theme.foreground).child({
                                let enterprise_attestation_set =
                                    fido.options.get("ep").copied().unwrap_or(false);
                                Tag::new(if enterprise_attestation_set {
                                    "已设置"
                                } else {
                                    "未设置"
                                })
                                .active(enterprise_attestation_set)
                            })),
                    )
                    .when(fido.remaining_discoverable_credentials.is_some(), |this| {
                        this.child(
                            h_flex()
                                .justify_between()
                                .items_center()
                                .child(
                                    div()
                                        .text_color(theme.muted_foreground)
                                        .child("剩余凭证"),
                                )
                                .child(
                                    div().font_medium().text_color(theme.foreground).child(
                                        fido.remaining_discoverable_credentials
                                            .unwrap_or(0)
                                            .to_string(),
                                    ),
                                ),
                        )
                    })
                    .into_any_element()
            } else {
                div()
                    .text_sm()
                    .text_color(theme.muted_foreground)
                    .child("FIDO信息不可用")
                    .into_any_element()
            })
    }

    fn render_led_config(status: &FullDeviceStatus, theme: &Theme) -> impl IntoElement {
        let config = &status.config;
        let has_fido_config =
            status.firmware_type == FirmwareType::RSKey || status.method != DeviceMethod::Fido;
        Card::new()
            .title("LED 配置")
            .icon(Icon::default().path("icons/microchip.svg"))
            .child(if !has_fido_config {
                v_flex()
                    .items_center()
                    .justify_center()
                    .py_4()
                    .gap_2()
                    .child(
                        Icon::new(IconName::TriangleAlert)
                            .size_8()
                            .text_color(gpui::yellow()),
                    )
                    .child(
                        div()
                            .text_sm()
                            .text_color(theme.muted_foreground)
                            .child("仅FIDO通信模式无法获取信息"),
                    )
                    .into_any_element()
            } else {
                v_flex()
                    .gap_3()
                    .text_sm()
                    .child(
                        h_flex()
                            .justify_between()
                            .child(
                                div()
                                    .text_color(theme.muted_foreground)
                                    .child("LED GPIO 引脚"),
                            )
                            .child(
                                config
                                    .led_gpio
                                    .map(|g| format!("GPIO {}", g))
                                    .unwrap_or_else(|| "固件默认值".into()),
                            ),
                    )
                    .child(
                        h_flex()
                            .justify_between()
                            .child(
                                div()
                                    .text_color(theme.muted_foreground)
                                    .child("LED 亮度"),
                            )
                            .child(
                                config
                                    .led_brightness
                                    .map(|b| b.to_string())
                                    .unwrap_or_else(|| "固件默认值".into()),
                            ),
                    )
                    .child(
                        h_flex()
                            .justify_between()
                            .child(
                                div()
                                    .text_color(theme.muted_foreground)
                                    .child("触摸超时时间"),
                            )
                            .child(
                                config
                                    .touch_timeout
                                    .map(|t| format!("{}s", t))
                                    .unwrap_or_else(|| "固件默认值".into()),
                            ),
                    )
                    .child(
                        h_flex()
                            .justify_between()
                            .child(
                                div()
                                    .text_color(theme.muted_foreground)
                                    .child("LED 可调光"),
                            )
                            .child(
                                Tag::new(if config.led_dimmable { "是" } else { "否" })
                                    .active(config.led_dimmable),
                            ),
                    )
                    .child(
                        h_flex()
                            .justify_between()
                            .child(
                                div()
                                    .text_color(theme.muted_foreground)
                                    .child("LED 常亮模式"),
                            )
                            .child(
                                Tag::new(if config.led_steady { "开启" } else { "关闭" })
                                    .active(config.led_steady),
                            ),
                    )
                    .into_any_element()
            })
    }

    fn render_security_status(status: &FullDeviceStatus, theme: &Theme) -> impl IntoElement {
        Card::new()
            .title("安全状态")
            .icon(Icon::default().path("icons/shield-check.svg"))
            .child(
                v_flex()
                    .gap_3()
                    .text_sm()
                    .child(
                        h_flex()
                            .justify_between()
                            .items_center()
                            .child(div().text_color(theme.muted_foreground).child("Boot 模式"))
                            .child(
                                h_flex()
                                    .gap_2()
                                    .items_center()
                                    .child(if status.secure_boot {
                                        Icon::default()
                                            .path("icons/lock.svg")
                                            .size_3p5()
                                            .text_color(gpui::green())
                                    } else {
                                        Icon::default()
                                            .path("icons/lock-open.svg")
                                            .size_3p5()
                                            .text_color(rgb(0xfe9a00))
                                    })
                                    .child(
                                        Tag::new(if status.secure_boot {
                                            "安全启动（Boot)"
                                        } else {
                                            "开发模式"
                                        })
                                        .active(status.secure_boot),
                                    ),
                            ),
                    )
                    .child(
                        h_flex()
                            .justify_between()
                            .items_center()
                            .child(
                                div()
                                    .text_color(theme.muted_foreground)
                                    .child("调试接口"),
                            )
                            .child(div().font_medium().text_color(theme.foreground).child(
                                if status.secure_lock {
                                    "已锁定读取"
                                } else {
                                    "启用调试"
                                },
                            )),
                    )
                    .child(
                        h_flex()
                            .justify_between()
                            .items_center()
                            .child(
                                div()
                                    .text_color(theme.muted_foreground)
                                    .child("安全锁定"),
                            )
                            .child(
                                Tag::new(if status.secure_lock {
                                    "已确认"
                                } else {
                                    "待处理"
                                })
                                .active(status.secure_lock),
                            ),
                    ),
            )
    }
}

impl Render for HomeViewModel {
    fn render(&mut self, window: &mut Window, cx: &mut Context<Self>) -> impl IntoElement {
        let device = self.device.read(cx);
        let connected = device.status.is_some();
        let is_wide = window.bounds().size.width > px(1100.0);
        let columns = if is_wide { 2 } else { 1 };

        PageView::build(
            "设备概述",
            "快速查看您的设备状态和规格",
            if !connected {
                div()
                    .flex()
                    .items_center()
                    .justify_center()
                    .h_64()
                    .border_1()
                    .border_color(cx.theme().border)
                    .rounded_xl()
                    .child(
                        div()
                            .text_color(cx.theme().muted_foreground)
                            .child("未连接设备"),
                    )
                    .into_any_element()
            } else {
                let status = device.status.as_ref().unwrap();
                div()
                    .grid()
                    .grid_cols(columns)
                    .gap_6()
                    .child(Self::render_device_info(status, cx.theme()))
                    .child(Self::render_fido_info(
                        device.fido_info.as_ref(),
                        cx.theme(),
                    ))
                    .child(Self::render_led_config(status, cx.theme()))
                    .child(Self::render_security_status(status, cx.theme()))
                    .into_any_element()
            },
            cx.theme(),
        )
    }
}
