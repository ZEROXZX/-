//! About screen — application version, licenses, firmware compatibility.

pub mod view;
pub mod view_model;
pub use view_model::AboutViewModel;
